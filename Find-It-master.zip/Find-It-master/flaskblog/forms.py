from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed,FileRequired
from flask_login import current_user
from wtforms import StringField, PasswordField, SubmitField, BooleanField , DateField,SelectField , DateTimeField, TextAreaField
from wtforms.validators import DataRequired, Length, Email, EqualTo, ValidationError , AnyOf
from werkzeug.utils import secure_filename
from flaskblog.models import User
from datetime import datetime
import re

class RegistrationForm(FlaskForm):
    fullname = StringField('Fullname', validators=[DataRequired(), Length(max=100)])
    contact = StringField('Contact', validators=[DataRequired(), Length(max=100)])
    course = StringField('Course', validators=[DataRequired(), Length(max=100)])
    student_no = StringField('Student No', validators=[DataRequired(), Length(min=2, max=20)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Sign Up')

    def validate_student_no(self, student_no):
        user = User.query.filter_by(student_no=student_no.data).first()
        if user:
            raise ValidationError('Student number is taken, please choose a different one.')
        
    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user:
            raise ValidationError('Email is taken, please choose a different one.')

class LoginForm(FlaskForm):
    studentno = StringField('Student No', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember = BooleanField('Remember me')
    submit = SubmitField('Login')

class UpdateAccountForm(FlaskForm):
    studentno = StringField('Student No', validators=[DataRequired(), Length(min=2, max=20)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    picture = FileField('Update Profile Picture', validators=[FileAllowed(['jpg', 'png'])])
    submit = SubmitField('Update')
    fullname = StringField('Fullname', validators=[DataRequired(), Length(max=100)])
    contact = StringField('Contact', validators=[DataRequired(), Length(max=100)])
    Course = StringField("Course", validators=[DataRequired(), Length(max=100)])    


    def validate_student_no(self, studentno):
        if studentno.data != current_user.studentno:
            studentno = User.query.filter_by(studentno=studentno.data).first()
            if studentno:
                raise ValidationError('Student number is taken, please choose a different one.')
        
    def validate_email(self, email):
        if email.data != current_user.email:
            studentno = User.query.filter_by(email=email.data).first()
            if studentno:
                raise ValidationError('Email is taken, please choose a different one.')

class RegisterItemFormss(FlaskForm):
    Studentno =StringField("Student No", validators=[DataRequired(), Length(max=100)])
    Fullname = StringField("Full Name", validators=[DataRequired(), Length(max=100)])
    Contact = StringField("Contact", validators=[DataRequired(), Length(max=100)])
    Course = StringField("Course", validators=[DataRequired(), Length(max=100)])
    date_lost = DateField("Date Lost", validators=[DataRequired()])
    location_lost = StringField("Location Lost", validators=[DataRequired(), Length(max=100)])
    category = StringField("Category", validators=[DataRequired(), Length(max=50)])
    item_name = StringField("Item Name", validators=[DataRequired(), Length(max=100)])
    type_item = SelectField("Type item", validators=[DataRequired()], choices=[('Non-Valuable', 'Non-Valuable'), ('Valuable', 'Valuable')])
    color = StringField("Color", validators=[DataRequired(), Length(max=50)])
    date_of_register = DateField("Date of Register", default=datetime.now)
    status = SelectField("Status", validators=[DataRequired()], choices=[('Lost', 'Lost'), ('Found', 'Found'), ('Register', 'Register')])
    image_item = FileField('Image', validators=[DataRequired()]) 
    description = StringField('Description', validators=[DataRequired(), Length(max=100)])
    submit = SubmitField('Submit')
  
    def validate_image_item(self, image_item):
        max_file_size = 5 * 1024 * 1024  
        if image_item.data:
            file_size = len(image_item.data.read())
            image_item.data.seek(0)  
            if file_size > max_file_size:
                raise ValidationError('File size exceeds 5MB limit.')

    def validate_item_name(self, item_name):
        if not re.match(r'^[A-Za-z0-9\s]+$', item_name.data):
            raise ValidationError('Item name must contain only letters, numbers, and spaces.')

    def validate_category(self, category):
        if len(category.data) > 50:
            raise ValidationError('Category cannot exceed 50 characters.')

    def validate_item_name(self, item_name):
        if len(item_name.data) > 100:
            raise ValidationError('Item name cannot exceed 100 characters.')

    def validate_type_item(self, type_item):
        if len(type_item.data) > 50:
            raise ValidationError('Type item cannot exceed 50 characters.')

    def validate_color(self, color):
        if len(color.data) > 50:
            raise ValidationError('Color cannot exceed 50 characters.')


class ReportItemForm(FlaskForm):
    date_lost = DateField("Date Lost", validators=[DataRequired()])
    location_lost = StringField("Location Lost", validators=[DataRequired(), Length(max=100)])
    item_name = StringField("Item Name", validators=[DataRequired(), Length(max=100)])
    type_item = SelectField("Type of Item", validators=[DataRequired()], choices=[('Non-Valuable', 'Non-Valuable'), ('Valuable', 'Valuable')])
    color = StringField("Color", validators=[DataRequired(), Length(max=50)])
    category = StringField("Category", validators=[DataRequired(), Length(max=50)])
    image_item = FileField('Image', validators=[DataRequired()])
    description = StringField('Description', validators=[DataRequired(), Length(max=300)])
    submit = SubmitField('Submit')

    def validate_image_item(self, image_item):
        max_file_size = 5 * 1024 * 1024
        if image_item.data:
            file_size = len(image_item.data.read())
            image_item.data.seek(0)
            if file_size > max_file_size:
                raise ValidationError('File size exceeds 5MB limit.')



class RegisterItemFormUser(FlaskForm):
    category = StringField("Category", validators=[DataRequired(), Length(max=50)])
    item_name = StringField("Item Name", validators=[DataRequired(), Length(max=100)])
    type_item = SelectField("Type of Item", validators=[DataRequired()], choices=[('Non-Valuable', 'Non-Valuable'), ('Valuable', 'Valuable')])
    color = StringField("Color", validators=[DataRequired(), Length(max=50)])
    image_item = FileField('Image', validators=[DataRequired()]) 
    description = StringField('Description', validators=[DataRequired(), Length(max=100)])
    submit = SubmitField('Submit')
  
    def validate_image_item(self, image_item):
        max_file_size = 5 * 1024 * 1024  
        if image_item.data:
            file_size = len(image_item.data.read())
            image_item.data.seek(0)  
            if file_size > max_file_size:
                raise ValidationError('File size exceeds 5MB limit.')

    def validate_item_name(self, item_name):
        if not re.match(r'^[A-Za-z0-9\s]+$', item_name.data):
            raise ValidationError('Item name must contain only letters, numbers, and spaces.')

    def validate_category(self, category):
        if len(category.data) > 50:
            raise ValidationError('Category cannot exceed 50 characters.')

    def validate_item_name_length(self, item_name):
        if len(item_name.data) > 100:
            raise ValidationError('Item name cannot exceed 100 characters.')

    def validate_type_item_length(self, type_item):
        if len(type_item.data) > 50:
            raise ValidationError('Type item cannot exceed 50 characters.')

    def validate_color_length(self, color):
        if len(color.data) > 50:
            raise ValidationError('Color cannot exceed 50 characters.')
